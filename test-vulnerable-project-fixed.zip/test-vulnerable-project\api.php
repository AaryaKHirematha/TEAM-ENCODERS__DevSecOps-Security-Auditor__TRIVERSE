<?php
// Secured PHP file

// FIX: Hardcoded credentials removed
$db_password = getenv('DB_PASSWORD');
$api_key = getenv('API_KEY');

// FIX: SQL injection - Use PDO with prepared statements
$user = $_GET['user'] ?? '';
// Assuming $pdo is a valid PDO connection
// $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
// $stmt->execute(['username' => $user]);
// $result = $stmt->fetchAll();

// FIX: Command injection - Remove shell functions, use safe alternatives
$filename = $_GET['file'] ?? '';
$safe_filename = basename($filename);
if (file_exists('/safe/path/' . $safe_filename)) {
    // Read file safely
    // echo file_get_contents('/safe/path/' . $safe_filename);
}

// FIX: XSS - Sanitize output
echo "<h1>Welcome, " . htmlspecialchars($_GET['name'] ?? '', ENT_QUOTES, 'UTF-8') . "</h1>";

// FIX: Unsafe deserialization - Use JSON
$data = json_decode($_POST['data'] ?? '{}', true);

// FIX: Weak crypto (MD5) - Use password_hash
// Note: $password should be defined before use
$password = $_POST['password'] ?? '';
$hash = password_hash($password, PASSWORD_DEFAULT);

// FIX: File inclusion - Use allowlist
$allowed_pages = ['home', 'about', 'contact'];
$page = $_GET['page'] ?? 'home';
if (in_array($page, $allowed_pages)) {
    include($page . '.php');
} else {
    echo "Invalid page";
}

// FIX: Debug mode - Turn off in production
error_reporting(0);
ini_set('display_errors', 0);
?>

/* Secured C code for scanner testing */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// FIX: Prevent Buffer overflow by using strncpy
void copy_input(char *input) {
    char buffer[64];
    if (input != NULL) {
        strncpy(buffer, input, sizeof(buffer) - 1);
        buffer[sizeof(buffer) - 1] = '\0';
        printf("Copied: %s\n", buffer);
    }
}

// FIX: Prevent Buffer overflow by using strncat
void concat_strings(char *a, char *b) {
    char result[128];
    if (a != NULL && b != NULL) {
        strncpy(result, a, sizeof(result) - 1);
        result[sizeof(result) - 1] = '\0';
        strncat(result, b, sizeof(result) - strlen(result) - 1);
    }
}

// FIX: Prevent Buffer overflow by using snprintf
void format_message(char *name) {
    char msg[100];
    if (name != NULL) {
        snprintf(msg, sizeof(msg), "Hello, %s! Welcome to our system.", name);
        printf("%s\n", msg);
    }
}

// FIX: Prevent Buffer overflow by using fgets instead of gets
void read_input() {
    char buffer[256];
    if (fgets(buffer, sizeof(buffer), stdin) != NULL) {
        // Remove trailing newline
        buffer[strcspn(buffer, "\n")] = 0;
        printf("You said: %s\n", buffer);
    }
}

// FIX: Prevent Format string vulnerability by supplying a literal format string
void log_message(char *msg) {
    if (msg != NULL) {
        printf("%s", msg);
    }
}

// FIX: Removed hardcoded passwords, they should be read from secure storage or env
const char *admin_password = NULL;
const char *api_key = NULL;

int main(int argc, char *argv[]) {
    if (argc > 1) {
        copy_input(argv[1]);
        log_message(argv[1]);
    }
    read_input();
    return 0;
}

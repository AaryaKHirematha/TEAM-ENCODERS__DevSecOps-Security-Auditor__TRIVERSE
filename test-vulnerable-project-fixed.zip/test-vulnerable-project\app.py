"""Secured Python app for scanner testing."""
import os
import json
import yaml
import subprocess
import hashlib
import secrets
import ast

# FIX: Removed hardcoded credentials
DATABASE_URL = os.environ.get("DATABASE_URL")
AWS_SECRET_KEY = os.environ.get("AWS_SECRET_KEY")
API_KEY = os.environ.get("API_KEY")
password = os.environ.get("DB_PASSWORD")
AWS_ACCESS_KEY_ID = os.environ.get("AWS_ACCESS_KEY_ID")

# FIX: Strong cryptography (SHA256 or bcrypt recommended; using sha256 here)
def hash_password_weak(pwd):
    return hashlib.sha256(pwd.encode()).hexdigest()

# FIX: Strong cryptography (SHA256)
def hash_token(token):
    return hashlib.sha256(token.encode()).hexdigest()

# FIX: Prevent command injection by avoiding shell=True
def run_user_command(user_input):
    subprocess.run(["echo", user_input], check=True)
    subprocess.run(["ls", user_input], check=True)

# FIX: SQL injection - Use parameterized queries
def get_user(username):
    # This should return a parameterized query tuple or use an ORM
    query = "SELECT * FROM users WHERE username = %s"
    return (query, (username,))

# FIX: Safe evaluation using ast.literal_eval
def calculate(expression):
    try:
        return ast.literal_eval(expression)
    except (ValueError, SyntaxError):
        return None

# FIX: Safe deserialization (JSON instead of Pickle)
def load_data(data):
    return json.loads(data)

# FIX: Safe YAML loading
def parse_config(yaml_str):
    return yaml.safe_load(yaml_str)

# FIX: Secure random token generation
def generate_token():
    return secrets.token_hex(16)

# FIX: Turn off debug mode in production
DEBUG = False
# Mock object to avoid NameError if app isn't defined
class App:
    pass
app = App()
app.debug = False

# FIX: Prevent path traversal
def read_file(filename):
    safe_filename = os.path.basename(filename)
    path = os.path.join("/uploads", safe_filename)
    try:
        with open(path, 'r') as f:
            return f.read()
    except Exception:
        return ""

# FIX: Removed hardcoded keys
JWT_SECRET = os.environ.get("JWT_SECRET")
STRIPE_KEY = os.environ.get("STRIPE_KEY")
SENDGRID_KEY = os.environ.get("SENDGRID_KEY")


#!/bin/bash
# Secured shell script for deployment

# FIX: Ensure environment variables are set before proceeding
if [ -z "$DATABASE_URL" ] || [ -z "$AWS_SECRET_ACCESS_KEY" ] || [ -z "$API_KEY" ] || [ -z "$STRIPE_SECRET" ] || [ -z "$ADMIN_PASSWORD" ]; then
    echo "Error: Required environment variables are missing."
    exit 1
fi

echo "Deploying application securely..."

# Deploy steps
docker build -t myapp .
docker push registry.example.com/myapp


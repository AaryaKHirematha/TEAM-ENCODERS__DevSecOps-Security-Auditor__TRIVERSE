// Secured Java application for scanner testing
import java.sql.*;
import java.io.*;
import java.security.MessageDigest;
import java.security.SecureRandom;

public class VulnerableApp {

    // FIX: Removed hardcoded credentials
    private static final String DB_URL = System.getenv("DB_URL");
    private static final String API_KEY = System.getenv("API_KEY");
    private static final String password = System.getenv("DB_PASSWORD");

    // FIX: SQL injection - Use PreparedStatement
    public ResultSet getUser(String username) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL);
        String query = "SELECT * FROM users WHERE username = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, username);
        return pstmt.executeQuery();
    }

    // FIX: Command injection - Use ProcessBuilder
    public void processFile(String filename) throws IOException {
        // Prevent path traversal by only keeping the filename
        String safeFilename = new File(filename).getName();
        
        ProcessBuilder pb1 = new ProcessBuilder("cat", safeFilename);
        pb1.start();
        
        ProcessBuilder pb2 = new ProcessBuilder("rm", "-rf", safeFilename);
        pb2.start();
    }

    // FIX: Unsafe deserialization - Prevent arbitrary object deserialization
    public Object deserialize(byte[] data) throws Exception {
        // Safe object deserialization would use Jackson or Gson.
        // For standard IO, we throw an exception to prevent gadget chains.
        throw new UnsupportedOperationException("ObjectInputStream is insecure. Use JSON serialization instead.");
    }

    // FIX: Weak cryptography (MD5) - Use SHA-256
    public String hashPassword(String pwd) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(pwd.getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // FIX: Insecure random - Use SecureRandom
    public int generateOTP() {
        SecureRandom sr = new SecureRandom();
        return sr.nextInt(1000000);
    }

    // FIX: Debug mode turned off
    public static boolean DEBUG = false;
}

// Secured Node.js server for scanner testing
const express = require('express');
const child_process = require('child_process');
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

const app = express();

// FIX: Removed hardcoded secrets, read from environment
const DB_PASSWORD = process.env.DB_PASSWORD;
const API_KEY = process.env.API_KEY;
const JWT_SECRET = process.env.JWT_SECRET;
const MONGO_URI = process.env.MONGO_URI;

// FIX: Removed hardcoded AWS keys
const AWS_ACCESS_KEY = process.env.AWS_ACCESS_KEY_ID;
const AWS_SECRET = process.env.AWS_SECRET_ACCESS_KEY;

// FIX: Removed eval() usage completely, use safe alternative or just a placeholder
app.get('/calc', (req, res) => {
    // Math expression parsing should use a safe library like math.js
    res.json({ error: "eval() removed for security" });
});

// FIX: Command injection via child_process - Use execFile and pass arguments safely
app.get('/ping', (req, res) => {
    const host = req.query.host || '127.0.0.1';
    child_process.execFile('ping', ['-c', '4', host], (err, stdout) => {
        res.send(stdout);
    });
});

// FIX: SQL injection - Use parameterized queries (dummy ORM pattern used here for illustration)
app.get('/user', (req, res) => {
    const query = "SELECT * FROM users WHERE id = ?";
    const params = [req.query.id];
    res.json({ query, params });
});

// FIX: Path traversal / Insecure file read
app.get('/file', (req, res) => {
    if (!req.query.name) return res.status(400).send("Name required");
    const safeName = path.basename(req.query.name);
    const safePath = path.join('/data/', safeName);
    try {
        const content = fs.readFileSync(safePath);
        res.send(content);
    } catch (err) {
        res.status(404).send("File not found");
    }
});

// FIX: XSS - reflected - Sanitize output, use JSON instead of sending raw HTML
app.get('/search', (req, res) => {
    // Avoid sending raw HTML with unescaped query
    res.json({ result: "Results for: " + req.query.q });
});

// FIX: Strong crypto (SHA-256 instead of MD5)
app.post('/hash', (req, res) => {
    if (!req.body || !req.body.data) return res.status(400).send("Data required");
    const hash = crypto.createHash('sha256').update(req.body.data).digest('hex');
    res.json({ hash });
});

// FIX: Secure random for tokens
app.get('/token', (req, res) => {
    const token = crypto.randomBytes(16).toString('hex');
    res.json({ token });
});

// FIX: Debug mode turned off
app.set('debug', false);

// FIX: Use process.env.PORT instead of hardcoded 3000
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

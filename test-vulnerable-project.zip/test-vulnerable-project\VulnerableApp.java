// Intentionally vulnerable Java application for scanner testing
import java.sql.*;
import java.io.*;
import java.security.MessageDigest;

public class VulnerableApp {

    // VULN: Hardcoded credentials
    private static final String DB_URL = "jdbc:mysql://admin:password123@prod-db.example.com:3306/app";
    private static final String API_KEY = "sk-proj-abc123def456ghi789jkl012mno345pqr678";
    private static final String password = "admin123!";

    // VULN: SQL injection
    public ResultSet getUser(String username) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL);
        Statement stmt = conn.createStatement();
        String query = "SELECT * FROM users WHERE username = '" + username + "'";
        return stmt.executeQuery(query);
    }

    // VULN: Command injection
    public void processFile(String filename) throws IOException {
        Runtime.getRuntime().exec("cat " + filename);
        Process p = Runtime.getRuntime().exec("rm -rf " + filename);
    }

    // VULN: Unsafe deserialization
    public Object deserialize(byte[] data) throws Exception {
        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data));
        return ois.readObject();
    }

    // VULN: Weak cryptography (MD5)
    public String hashPassword(String pwd) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(pwd.getBytes());
        return new String(digest);
    }

    // VULN: Insecure random
    public int generateOTP() {
        return (int)(Math.random() * 1000000);
    }

    // VULN: Debug mode
    public static boolean DEBUG = true;
}

"""Intentionally vulnerable Python app for scanner testing."""
import os
import pickle
import yaml
import subprocess
import hashlib
import random

# VULN: Hardcoded credentials
DATABASE_URL = "postgres://admin:SuperSecret123@db.prod.example.com:5432/production"
AWS_SECRET_KEY = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
API_KEY = "sk-proj-abc123def456ghi789jkl012mno345pqr678"
password = "admin123!"

# VULN: Hardcoded AWS access key
AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"

# VULN: Weak cryptography (MD5)
def hash_password_weak(pwd):
    return hashlib.md5(pwd.encode()).hexdigest()

# VULN: Weak cryptography (SHA1)
def hash_token(token):
    return hashlib.sha1(token.encode()).hexdigest()

# VULN: Command injection
def run_user_command(user_input):
    os.system("echo " + user_input)
    subprocess.call("ls " + user_input, shell=True)

# VULN: SQL injection
def get_user(username):
    query = "SELECT * FROM users WHERE username = '" + username + "'"
    return query

# VULN: eval() usage
def calculate(expression):
    return eval(expression)

# VULN: Unsafe deserialization
def load_data(data):
    return pickle.loads(data)

# VULN: Unsafe YAML loading
def parse_config(yaml_str):
    return yaml.load(yaml_str)

# VULN: Insecure random
def generate_token():
    return str(random.random())

# VULN: Debug mode
DEBUG = True
app.debug = True

# VULN: Insecure file read
def read_file(filename):
    path = "/uploads/" + filename
    return open(path).read()

# VULN: Hardcoded JWT
JWT_SECRET = "secret"
STRIPE_KEY = "sk_live_abc123def456ghi789jkl012mno345pqr"
SENDGRID_KEY = "SG.abc123def456ghi789jkl.012mno345pqr678stu901vwx234yz"

/* Intentionally vulnerable C code for scanner testing */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// VULN: Buffer overflow — strcpy
void copy_input(char *input) {
    char buffer[64];
    strcpy(buffer, input);  // No bounds checking
    printf("Copied: %s\n", buffer);
}

// VULN: Buffer overflow — strcat
void concat_strings(char *a, char *b) {
    char result[128];
    strcpy(result, a);
    strcat(result, b);  // No bounds checking
}

// VULN: Buffer overflow — sprintf
void format_message(char *name) {
    char msg[100];
    sprintf(msg, "Hello, %s! Welcome to our system.", name);
    printf("%s\n", msg);
}

// VULN: Buffer overflow — gets
void read_input() {
    char buffer[256];
    gets(buffer);  // Never use gets()
    printf("You said: %s\n", buffer);
}

// VULN: Format string vulnerability
void log_message(char *msg) {
    printf(msg);  // Format string vuln — should be printf("%s", msg)
}

// VULN: Hardcoded password
const char *admin_password = "SuperSecret123!";
const char *api_key = "sk-proj-abc123def456ghi789jkl012mno345pqr678";

int main(int argc, char *argv[]) {
    if (argc > 1) {
        copy_input(argv[1]);
        log_message(argv[1]);
    }
    read_input();
    return 0;
}

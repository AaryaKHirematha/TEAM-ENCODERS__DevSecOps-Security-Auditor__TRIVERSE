// Intentionally vulnerable Node.js server for scanner testing
const express = require('express');
const child_process = require('child_process');
const fs = require('fs');
const crypto = require('crypto');

const app = express();

// VULN: Hardcoded secrets
const DB_PASSWORD = "SuperSecretPassword123!";
const API_KEY = "sk-proj-abc123def456ghi789jkl012mno345pqr678";
const JWT_SECRET = "secret";
const MONGO_URI = "mongodb://admin:password123@prod-db.example.com:27017/myapp";

// VULN: Hardcoded AWS keys
const AWS_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE";
const AWS_SECRET = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY";

// VULN: eval() usage
app.get('/calc', (req, res) => {
    const result = eval(req.query.expression);
    res.json({ result });
});

// VULN: Command injection via child_process
app.get('/ping', (req, res) => {
    const host = req.query.host;
    child_process.exec('ping -c 4 ' + host, (err, stdout) => {
        res.send(stdout);
    });
});

// VULN: SQL injection
app.get('/user', (req, res) => {
    const query = "SELECT * FROM users WHERE id = " + req.query.id;
    res.json({ query });
});

// VULN: Path traversal / Insecure file read
app.get('/file', (req, res) => {
    const content = fs.readFileSync('/data/' + req.query.name);
    res.send(content);
});

// VULN: XSS - reflected
app.get('/search', (req, res) => {
    res.send('<h1>Results for: ' + req.query.q + '</h1>');
    document.write(req.query.q);
});

// VULN: Weak crypto (MD5)
app.post('/hash', (req, res) => {
    const hash = crypto.createHash('md5').update(req.body.data).digest('hex');
    res.json({ hash });
});

// VULN: Insecure random for tokens
app.get('/token', (req, res) => {
    const token = Math.random().toString(36);
    res.json({ token });
});

// VULN: Debug mode
app.set('debug', true);

// VULN: No helmet, no rate limiting, no CSRF protection
app.listen(3000, () => console.log('Vulnerable server running'));

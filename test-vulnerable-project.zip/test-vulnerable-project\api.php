<?php
// Intentionally vulnerable PHP file

// VULN: Hardcoded credentials
$db_password = "admin123!";
$api_key = "sk-proj-abc123def456ghi789jkl012mno345pqr678";

// VULN: SQL injection
$user = $_GET['user'];
$query = "SELECT * FROM users WHERE username = '$user'";
$result = mysql_query($query);

// VULN: Command injection
$filename = $_GET['file'];
system("cat " . $filename);
shell_exec("grep " . $_GET['pattern'] . " /var/log/app.log");

// VULN: XSS
echo "<h1>Welcome, " . $_GET['name'] . "</h1>";

// VULN: Unsafe deserialization
$data = unserialize($_POST['data']);

// VULN: Weak crypto (MD5)
$hash = md5($password);

// VULN: File inclusion
include($_GET['page'] . '.php');

// VULN: Debug mode
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

#!/bin/bash
# Intentionally vulnerable shell script for scanner testing

# VULN: Hardcoded secrets
export DATABASE_URL="postgres://admin:SuperSecret123@db.prod.example.com:5432/production"
export AWS_SECRET_ACCESS_KEY="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
export API_KEY="sk-proj-abc123def456ghi789jkl012mno345pqr678"
export STRIPE_SECRET="sk_live_abc123def456ghi789jkl012mno345pqr"

# VULN: Hardcoded password
ADMIN_PASSWORD="admin123!"
DB_PASS="SuperSecretPassword"

echo "Deploying with password: $ADMIN_PASSWORD"

# Deploy steps
docker build -t myapp .
docker push registry.example.com/myapp
